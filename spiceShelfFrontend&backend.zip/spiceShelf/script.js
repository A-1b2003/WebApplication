const recipes = [

{
name:"Creamy Garlic Pasta",
category:"main",
image:"images/pasta.AVIF",
description:"Creamy pasta with garlic sauce",
ingredients:["200g pasta","2 cloves garlic","1 cup cream"],
steps:["Boil pasta","Cook garlic","Add cream"]
},

{
name:"Chocolate Cake",
category:"dessert",
image:"images/cake.AVIF",
description:"Soft chocolate cake",
ingredients:["flour","cocoa","eggs"],
steps:["Mix ingredients","Bake"]
},

{
name:"Veggie Salad",
category:"salad",
image:"images/salad.WEBP",
description:"Fresh healthy salad",
ingredients:["lettuce","tomato","cucumber"],
steps:["Chop vegetables","Mix dressing"]
},

{
name:"Chicken Burger",
category:"main",
image:"images/burger.AVIF",
description:"Juicy homemade chicken burger",
ingredients:[
"Burger bun","Chicken patty","Lettuce","Cheese","Mayonnaise"],
steps:["Cook chicken patty","Toast bun","Assemble burger with toppings"]
},

{
name:"Pancakes",
category:"breakfast",
image:"images/pancakes.AVIF",
description:"Fluffy pancakes",
ingredients:["flour","milk","egg"],
steps:["Make batter","Cook on pan"]
},

{
name:"Fruit Smoothie",
category:"drink",
image:"images/smoothie.AVIF",
description:"Healthy smoothie",
ingredients:["banana","berries","yogurt"],
steps:["Blend ingredients","Serve cold"]
}

];

const cardsContainer = document.getElementById("cardsContainer");

const searchBox = document.getElementById("searchBox");

const categorySelect = document.getElementById("categorySelect");

function renderCards(list){

cardsContainer.innerHTML="";

list.forEach((recipe,index)=>{

const card=document.createElement("div");

card.className="col-md-4 recipe-card";

card.innerHTML=`

<div class="card h-100">

<img src="${recipe.image}" class="card-img-top">

<div class="card-body">

<h5 class="card-title">${recipe.name}</h5>

<p class="card-text">${recipe.description}</p>

<button class="btn btn-warning viewBtn">View Recipe</button>

</div>

</div>

`;

cardsContainer.appendChild(card);

card.querySelector(".viewBtn").addEventListener("click",()=>{

showRecipe(recipe);

});

});

}

function showRecipe(recipe){
  document.getElementById("modalRecipeImage").src = recipe.image;
  document.getElementById("modalRecipeName").innerText = recipe.name;
  document.getElementById("modalIngredients").innerHTML = recipe.ingredients.map(i => `<li>${i}</li>`).join('');
  document.getElementById("modalSteps").innerHTML = recipe.steps.map(s => `<li>${s}</li>`).join('');

  // Show the modal
  const modal = new bootstrap.Modal(document.getElementById('recipeModal'));
  modal.show();
}

function filterRecipes(){

const search=searchBox.value.toLowerCase();

const category=categorySelect.value;

const filtered=recipes.filter(r=>{

const matchSearch=r.name.toLowerCase().includes(search);

const matchCategory=(category==="all" || r.category===category);

return matchSearch && matchCategory;

});

renderCards(filtered);

}

searchBox.addEventListener("input",filterRecipes);

categorySelect.addEventListener("change",filterRecipes);

renderCards(recipes);


