<?php
include("../includes/db.php");

if($_SERVER["REQUEST_METHOD"] == "POST"){
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

    $conn->query("INSERT INTO users (username,email,password) VALUES ('$username','$email','$password')");

    header("Location: login.php");
}
?>

<form method="POST">
<input name="username" placeholder="Username" required>
<input name="email" type="email" required>
<input name="password" type="password" required>
<button type="submit">Register</button>
</form>