<?php
session_start();
include("../includes/db.php");

if($_SERVER["REQUEST_METHOD"] == "POST"){
    $email = $_POST['email'];
    $password = $_POST['password'];

    $result = $conn->query("SELECT * FROM users WHERE email='$email'");
    $user = $result->fetch_assoc();

    if($user && password_verify($password, $user['password'])){
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['username'] = $user['username'];

        header("Location: ../index.php");
    } else {
        echo "Invalid login";
    }
}
?>

<form method="POST">
<input name="email" type="email" required>
<input name="password" type="password" required>
<button type="submit">Login</button>
</form>