<?php
session_start();
require_once "includes/db.php"; // your DB connection file

// Initialize filter values
$search = isset($_GET['search']) ? trim($_GET['search']) : '';
$category = isset($_GET['category']) ? $_GET['category'] : 'all';

// Prepare SQL query
$sql = "SELECT * FROM recipes WHERE 1=1";

// Add category filter if not "all"
if ($category !== 'all') {
    $sql .= " AND category = ?";
}

// Add search filter if not empty
if ($search !== '') {
    $sql .= " AND title LIKE ?";
}

// Prepare statement
$stmt = $conn->prepare($sql);

// Bind parameters dynamically
if ($category !== 'all' && $search !== '') {
    $likeSearch = "%$search%";
    $stmt->bind_param("ss", $category, $likeSearch);
} elseif ($category !== 'all') {
    $stmt->bind_param("s", $category);
} elseif ($search !== '') {
    $likeSearch = "%$search%";
    $stmt->bind_param("s", $likeSearch);
}

// Execute and get results
$stmt->execute();
$result = $stmt->get_result();
$recipes = $result->fetch_all(MYSQLI_ASSOC);
?>


<!DOCTYPE html>

<html lang="en">
<head>

  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">

  <title>SpiceShelf Recipe Book</title>

  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="style.css">

</head>

<body>

  <!-- NAVBAR -->

<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <div class="container">

    <a class="navbar-brand d-flex align-items-center" href="index.php">
      <img src="images/logo.png" alt="SpiceShelf Logo" height="40" class="me-2">
      SpiceShelf
    </a>

    <button class="navbar-toggler" data-bs-toggle="collapse" data-bs-target="#menu">
      <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="menu">

      <ul class="navbar-nav ms-auto">

        <li class="nav-item">
          <a class="nav-link active" href="index.php">Home</a>
        </li>

        <li class="nav-item">
          <a class="nav-link" href="features.php">Features</a>
        </li>

        <li class="nav-item">
          <a class="nav-link" href="contact.php">Contact</a>
        </li>

        <?php if(isset($_SESSION['user_id'])): ?>
          <li class="nav-item">
            <span class="nav-link text-white">Hello, <?= $_SESSION['username'] ?></span>
          </li>
          <li class="nav-item">
            <a class="nav-link btn btn-danger text-white ms-2" href="auth/logout.php">Logout</a>
          </li>
        <?php else: ?>
          <li class="nav-item">
            <a class="nav-link btn btn-warning text-dark ms-2" href="auth/login.php">Login</a>
          </li>
          <li class="nav-item">
            <a class="nav-link btn btn-success text-white ms-2" href="auth/register.php">Register</a>
          </li>
        <?php endif; ?>

      </ul>

    </div>
  </div>
</nav>


    <!-- SEARCH + CATEGORY -->

  <form method="GET" class="row mb-4">
  <div class="col-md-8">
    <input type="text" name="search" class="form-control" placeholder="Search recipes" 
           value="<?= isset($_GET['search']) ? htmlspecialchars($_GET['search']) : '' ?>">
  </div>

  <div class="col-md-4">
    <select name="category" class="form-select">
      <option value="all">All Categories</option>
      <option value="main" <?= (isset($_GET['category']) && $_GET['category']=='main')?'selected':'' ?>>Main Course</option>
      <option value="dessert" <?= (isset($_GET['category']) && $_GET['category']=='dessert')?'selected':'' ?>>Dessert</option>
      <option value="salad" <?= (isset($_GET['category']) && $_GET['category']=='salad')?'selected':'' ?>>Salad</option>
      <option value="breakfast" <?= (isset($_GET['category']) && $_GET['category']=='breakfast')?'selected':'' ?>>Breakfast</option>
      <option value="drink" <?= (isset($_GET['category']) && $_GET['category']=='drink')?'selected':'' ?>>Drink</option>
    </select>
  </div>
</form>



  <h2 class="text-center mb-4">Popular Recipes</h2>

  <div class="row" id="cardsContainer">
    <?php
    require_once "includes/db.php"; // connect to DB
    $result = $conn->query("SELECT * FROM recipes ORDER BY id DESC LIMIT 6"); // latest 6 recipes
    if($result->num_rows > 0){
      while($row = $result->fetch_assoc()){
        echo '<div class="col-md-4 mb-4">';
        echo '<div class="card">';
        if($row['image']) echo '<img src="'.$row['image'].'" class="card-img-top">';
        echo '<div class="card-body">';
        echo '<h5 class="card-title">'.htmlspecialchars($row['title']).'</h5>';
        echo '<p class="card-text">'.htmlspecialchars($row['ingredients']).'</p>';
        echo '</div></div></div>';
      }
} else {
    echo '<p class="text-center">No recipes yet.</p>';
}
?>
  </div>

  </div>

  

  </div>


  <!-- HERO CAROUSEL -->

  <div id="carouselExample" class="carousel slide" data-bs-ride="carousel">

  <div class="carousel-inner">

  <div class="carousel-item active">
  <img src="images/salad.webp" class="d-block w-100">
  </div>

  <div class="carousel-item">
  <img src="images/pancakes.AVIF" class="d-block w-100">
  </div>

  <div class="carousel-item">
  <img src="images/cake.AVIF" class="d-block w-100">
  </div>

  <div class="carousel-caption">

  <h2>Discover Delicious Recipes With Us!</h2>

  <p>Search, save and cook amazing meals</p>

  </div>

  </div>

  </div>
  <button class="carousel-control-prev" type="button" data-bs-target="#carouselExample" data-bs-slide="prev">

  <span class="carousel-control-prev-icon"></span>

  </button>

  <button class="carousel-control-next" type="button" data-bs-target="#carouselExample" data-bs-slide="next">

  <span class="carousel-control-next-icon"></span>

  </button>



  <!-- FOOTER -->

  <footer class="bg-dark text-white text-center p-3 mt-5">

  <p>© 2026 SpiceShelf Recipe Book</p>

  </footer>

  <script src="script.js"></script>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>


  <!-- Recipe Modal -->
  <div class="modal fade" id="recipeModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="modalRecipeName"></h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
        </div>
        <div class="modal-body">
          <img id="modalRecipeImage" class="img-fluid mb-3" src="">
          <h6>Ingredients:</h6>
          <ul id="modalIngredients"></ul>
          <h6>Steps:</h6>
          <ol id="modalSteps"></ol>
        </div>
      </div>
    </div>
  </div>

</body>
</html>
