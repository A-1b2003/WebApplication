<?php session_start(); ?>
<!DOCTYPE html>

<html>

<head>

<title>Features</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="style.css">
</head>

<body>

<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <div class="container">

    <a class="navbar-brand d-flex align-items-center" href="index.php">
      <img src="images/logo.png" alt="SpiceShelf Logo" height="40" class="me-2">
      SpiceShelf
    </a>

    <div class="navbar-nav ms-auto">

      <a class="nav-link" href="index.php">Home</a>
      <a class="nav-link active" href="features.php">Features</a>
      <a class="nav-link" href="contact.php">Contact</a>

      <?php if(isset($_SESSION['user_id'])): ?>
        <span class="nav-link text-white">Hello, <?= $_SESSION['username'] ?></span>
        <a class="nav-link btn btn-danger text-white ms-2" href="auth/logout.php">Logout</a>
      <?php else: ?>
        <a class="nav-link btn btn-warning text-dark ms-2" href="auth/login.php">Login</a>
        <a class="nav-link btn btn-success text-white ms-2" href="auth/register.php">Register</a>
      <?php endif; ?>

    </div>

  </div>
</nav>

<div class="container mt-5">

<h2>App Features</h2>

<ul class="list-group">

<li class="list-group-item">Search Recipes</li>
<li class="list-group-item">Category Filtering</li>
<li class="list-group-item">Dynamic Recipe Display</li>
<li class="list-group-item">Responsive Design</li>

</ul>

</div>

</body>

</html>
