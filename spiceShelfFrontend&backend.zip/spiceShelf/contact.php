<?php
session_start();
require_once "includes/db.php"; // this is your DB connection file
?>

<!DOCTYPE html>
<html>
<head>
<title>Contact / Submit Recipe</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="style.css">
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <div class="container">
    <a class="navbar-brand d-flex align-items-center" href="index.php">
      <img src="images/logo.png" alt="SpiceShelf Logo" height="40" class="me-2">
      SpiceShelf
    </a>

    <div class="navbar-nav ms-auto">
      <a class="nav-link" href="index.php">Home</a>
      <a class="nav-link" href="features.php">Features</a>
      <a class="nav-link active" href="contact.php">Contact</a>

      <?php if(isset($_SESSION['user_id'])): ?>
        <span class="nav-link text-white">Hello, <?= htmlspecialchars($_SESSION['username']) ?></span>
        <a class="nav-link btn btn-danger text-white ms-2" href="auth/logout.php">Logout</a>
      <?php else: ?>
        <a class="nav-link btn btn-warning text-dark ms-2" href="auth/login.php">Login</a>
        <a class="nav-link btn btn-success text-white ms-2" href="auth/register.php">Register</a>
      <?php endif; ?>
    </div>
  </div>
</nav>


<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $title = $_POST['recipeName'];
    $email = $_POST['email'];
    $ingredients = $_POST['ingredients'];
    $steps = $_POST['steps'];

    // get user id if logged in, else 0 (or NULL)
    $user_id = isset($_SESSION['user_id']) ? $_SESSION['user_id'] : 0;

    // handle image upload
    $image_path = '';
    if(isset($_FILES['image']) && $_FILES['image']['error'] === 0){
        $img_name = time() . '_' . $_FILES['image']['name'];
        $img_tmp = $_FILES['image']['tmp_name'];
        $img_dir = 'uploads/' . $img_name; // make sure uploads/ exists
        move_uploaded_file($img_tmp, $img_dir);
        $image_path = $img_dir;
    }

    // Insert into recipes table
    $stmt = $conn->prepare("INSERT INTO recipes (title, ingredients, instructions, user_id, image) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("sssis", $title, $ingredients, $steps, $user_id, $image_path);
    if($stmt->execute()){
        $success = "Recipe submitted successfully!";
    } else {
        $error = "Error: " . $stmt->error;
    }

}
?>


<div class="container mt-5">
  <h2>Submit Your Recipe</h2>
  <?php if(isset($success)) echo '<div class="alert alert-success">'.$success.'</div>'; ?>
  <?php if(isset($error)) echo '<div class="alert alert-danger">'.$error.'</div>'; ?>
  <form method="POST" enctype="multipart/form-data">
    
    <div class="mb-3">
      <label class="form-label">Recipe Name</label>
      <input type="text" class="form-control" name="recipeName" required>
    </div>

    <div class="mb-3">
      <label class="form-label">Your Email</label>
      <input type="email" class="form-control" name="email" required>
    </div>

    <div class="mb-3">
      <label class="form-label">Ingredients (comma separated)</label>
      <textarea class="form-control" name="ingredients" placeholder="e.g., 2 eggs, 200g flour" required></textarea>
    </div>

    <div class="mb-3">
      <label class="form-label">Cooking Steps (one per line)</label>
      <textarea class="form-control" name="steps" placeholder="Boil water&#10;Add pasta&#10;Cook for 10 mins" required></textarea>
    </div>

    <div class="mb-3">
      <label class="form-label">Recipe Image</label>
      <input type="file" class="form-control" name="image" accept="image/*">
    </div>

    <button type="submit" class="btn btn-warning">Send Recipe</button>

  </form>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>